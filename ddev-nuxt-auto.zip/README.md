# ddev-nuxt-auto
Auto-run Nuxt.js dev server inside DDEV.

## Installation
```
ddev add-on get ddev-nuxt-auto.zip
ddev restart
```

Nuxt will auto-start on port :3000 and be available at:
https://<project>.ddev.site:3001
